# The Anatomy of Online Toxicity

A Python data-visualization project exploring the patterns, language, and structure of toxic comments in Wikipedia talk-page discussions.

## Overview

This project turns a cleaned toxic-comment dataset into a visual story for a non-technical audience. It examines the scale of toxicity, category distribution, label co-occurrence, vocabulary differences, comment-length patterns, and linguistic signals.

## Key Findings

- 16,153 of 157,379 analyzed comments (10.3%) were flagged as toxic in at least one category.
- General toxicity, obscenity, and insults make up most flagged content.
- Toxic comments often receive multiple labels rather than a single label.
- Toxic comments tend to be shorter, use more capital letters, and contain more exclamation marks.
- Threats are uncommon and should be treated as a separate moderation priority.

## Repository Layout

```text
src/          Reusable Python modules
data/         Dataset instructions; raw data is excluded from Git
notebooks/    Analysis and story notebooks
scripts/      Reproducible entry-point scripts
outputs/      Generated figures
reports/      Final report and documentation
```

## Setup

```bash
pip install -r requirements.txt
```

Place the source data at `data/raw/train.csv`, then run:

```bash
python scripts/run_analysis.py
python scripts/generate_figures.py
```

## Dataset

This project is based on the Wikipedia Toxic Comment Classification dataset. The source dataset is not included in this repository; see `data/README.md` for the expected format.

## Author

Apoorv  
Data Science Internship — Week 2
