from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.config import PROCESSED_DATA_PATH, FIGURES_DIR
from src.visualizations import plot_toxicity_share, plot_category_counts


def main():
    if not PROCESSED_DATA_PATH.exists():
        raise FileNotFoundError("Run scripts/run_analysis.py before generating figures.")

    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(PROCESSED_DATA_PATH)
    plot_toxicity_share(df, FIGURES_DIR / "01_toxicity_share.png")
    plot_category_counts(df, FIGURES_DIR / "02_toxicity_categories.png")
    print(f"Figures saved to: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
