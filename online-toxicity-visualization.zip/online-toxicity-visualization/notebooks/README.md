# Notebooks

Use this directory for exploratory and presentation notebooks.

Suggested notebooks:

- `01_data_overview.ipynb` — data quality checks and label overview
- `02_visualization_story.ipynb` — final narrative visualizations
