# Data

The original dataset is intentionally not included in this repository.

Add the source CSV as:

```text
data/raw/train.csv
```

Expected columns:

- `comment_text`
- `toxic`
- `severe_toxic`
- `obscene`
- `threat`
- `insult`
- `identity_hate`

Processed files may be stored in `data/processed/`. Do not commit restricted or large raw datasets to GitHub.
