# Outputs

Generated charts are stored in `outputs/figures/`.

Expected figures:

- `01_toxicity_share.png`
- `02_toxicity_categories.png`
- `03_label_combinations.png`
- `04_word_comparison.png`
- `05_comment_length.png`
- `06_toxicity_profile.png`
