from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
RAW_DATA_PATH = ROOT_DIR / "data" / "raw" / "train.csv"
PROCESSED_DATA_PATH = ROOT_DIR / "data" / "processed" / "cleaned_comments.csv"
FIGURES_DIR = ROOT_DIR / "outputs" / "figures"

TOXICITY_COLUMNS = [
    "toxic",
    "severe_toxic",
    "obscene",
    "threat",
    "insult",
    "identity_hate",
]
