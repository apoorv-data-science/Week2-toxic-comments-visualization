import pandas as pd


def clean_comments(df: pd.DataFrame) -> pd.DataFrame:
    """Apply lightweight text cleaning while preserving the original text."""
    df = df.copy()
    df["comment_text"] = df["comment_text"].fillna("").astype(str)
    df["clean_comment"] = df["comment_text"].str.replace(r"\s+", " ", regex=True).str.strip()
    return df


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add simple, interpretable features used in the visual story."""
    df = df.copy()
    text = df["comment_text"].fillna("").astype(str)
    df["char_length"] = text.str.len()
    df["word_count"] = text.str.split().str.len()
    df["exclamation_count"] = text.str.count("!")
    df["capital_ratio"] = text.apply(lambda value: sum(c.isupper() for c in value) / max(len(value), 1))
    return df
