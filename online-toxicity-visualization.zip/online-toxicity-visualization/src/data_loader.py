import pandas as pd
from .config import RAW_DATA_PATH


def load_raw_data(path=RAW_DATA_PATH):
    """Load the source toxic-comment dataset."""
    return pd.read_csv(path)
